// Contact Form Validation
document.getElementById('contactForm').addEventListener('submit', function(e) {
    if (!this.checkValidity()) {
        e.preventDefault();
        alert('Please fill out all required fields correctly!');
    }
});

// Survey Form Validation
document.getElementById('surveyForm').addEventListener('submit', function(e) {
    if (!this.checkValidity()) {
        e.preventDefault();
        alert('Please complete all required survey fields!');
    }
});

// Dark Mode Toggle
const themeToggle = document.createElement('button');
themeToggle.textContent = '🌓 Toggle Theme';
document.body.prepend(themeToggle);

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});
